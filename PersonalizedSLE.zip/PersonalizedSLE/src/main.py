import pandas as pd
import numpy as np
import os
np.random.seed(180205)
import math
from sle_model import LSTM_Model
from data_loader import read_data, preprocess
from map_matcher import MapMatcher
from matplotlib import pyplot as plt

# def test_map_matcher():
#     matcher = MapMatcher()
#     PDR_OBS = [[pdrdata['PathDis'][i], pdrdata['PathDir'][i]] for i in range(1, pdrdata.shape[0])]
#     max_path, max_p = matcher.viterbi_decode(PDR_OBS)
#     print(max_path, max_p)

def test_sle_model():
    TEST_DATA_DIRE = '../data/test_data/'
    test_data = read_data(TEST_DATA_DIRE)
    test_acc, test_gyr, test_mag, test_feat, test_steps = preprocess(test_data)

    test_dataset = {'data': [test_acc, test_gyr, test_feat], 'label': test_steps}
    model = LSTM_Model().model
    pred = model.predict(test_dataset['data']).reshape(-1,)
    print(pred)

def norm(vec):
    return np.linalg.norm(vec)

def dot_product(vec1, vec2):
    return np.sum([vec1[i] * vec2[i] for i in range(len(vec1))])

def scale(vec, scale):
    return [vec[0] * scale, vec[1] * scale]

def calculate_included_angle(vec1, vec2):
    theta = math.acos(np.clip(dot_product(vec1, vec2) / (norm(vec1) * norm(vec2)), a_min = -1, a_max = 1)) / np.pi * 180
    if (vec2[0] * vec1[1] - vec1[0] * vec2[1] < 0): theta = -theta
    return theta

def rotate_vector(vec, angle):
    angle = angle / 180 * np.pi
    new_vec = np.matrix([[np.cos(angle), np.sin(angle), 0], [-np.sin(angle), np.cos(angle), 0], [0, 0, 1]]) * np.matrix(vec + [1]).T
    return [new_vec[0, 0], new_vec[1, 0]]

def calculate_distance(p1, p2):
    return np.linalg.norm([p2[0] - p1[0], p2[1] - p1[1]])

def angle_mean(angle_list):
    count = 0
    if len(angle_list) == 0: return 0
    positiveList = []
    negativeList = []
    for angle in angle_list:
        if angle >= 0: positiveList.append(angle)
        else: negativeList.append(angle)
        if abs(angle) > 90: count += 1

    positive = len(positiveList)
    num = len(angle_list)
    if (positive == 0) | (positive == num): return np.mean(angle_list)
    avgPositive = np.mean(positiveList)
    avgNegative = np.mean(negativeList)
    angleDifferenceABS = abs(avgPositive - avgNegative)
    angleDifference = 0

    if angleDifferenceABS >= 180: angleDifference = 360 - angleDifferenceABS
    else: angleDifference = angleDifferenceABS
    avgPiece = angleDifference / num

    if abs(avgNegative) + abs(avgPositive) > 180:
        res = avgNegative - len(positiveList) * avgPiece
        if res < -180: res += 360
    else:
        res = avgNegative + len(positiveList) * avgPiece
    return res

def get_gyr_diff(data):
    av_sum = 0
    av, timestamp = data['gyr_z'].values, data['timestamp'].values
    for i in range(1, len(av)):
        if i == 1:
            av_sum += (av[i - 1] + av[i]) * (timestamp[i] - timestamp[i - 1]) * 1e-3 * 180 / np.pi
        else:
            av_sum += (av[i - 1] + av[i]) * (timestamp[i] - timestamp[i - 1]) * 1e-3 * 180 / np.pi / 2
    return av_sum

# 每一段按步子数均分
def divide_segs_by_avg(matcher, path, dis_list, pred_sl_segs, real_sl_segs):
    labels = []
    pred_sl_before = []
    real_sl = []
    for i in range(1, len(path)):
        # print(matcher.Dis[path[i - 1], path[i]], dis_list[i - 1][1], dis_list[i - 1][0], np.sum(real_sl_segs[i - 1]))
        straight_ratio = dis_list[i - 1][0] / np.sum(pred_sl_segs[i - 1])
        len_ratio = matcher.Dis[path[i - 1], path[i]] / dis_list[i - 1][0]
        print(straight_ratio, len_ratio)
        labels.append([dis_list[i - 1][0]/len(pred_sl_segs[i - 1]) for pred_sl in pred_sl_segs[i - 1]])
        pred_sl_before.append([pred_sl for pred_sl in pred_sl_segs[i - 1]])
        real_sl.append([real_sl for real_sl in real_sl_segs[i - 1]])
    return labels, pred_sl_before, real_sl

def divide_segs_by_len_ratio(matcher, path, dis_list, pred_sl_segs, real_sl_segs):
    labels = []
    pred_sl_before = []
    real_sl = []
    for i in range(1, len(path)):
        # print(matcher.Dis[path[i - 1], path[i]], dis_list[i - 1][1], dis_list[i - 1][0], np.sum(real_sl_segs[i - 1]))
        straight_ratio = dis_list[i - 1][0] / np.sum(pred_sl_segs[i - 1])
        len_ratio = matcher.Dis[path[i - 1], path[i]] / dis_list[i - 1][0]
        print(straight_ratio, len_ratio)
        labels.append([pred_sl * len_ratio for pred_sl in pred_sl_segs[i - 1]])
        pred_sl_before.append([pred_sl for pred_sl in pred_sl_segs[i - 1]])
        real_sl.append([real_sl for real_sl in real_sl_segs[i - 1]])
    return labels, pred_sl_before, real_sl

def divide_segs_by_len_ratio_cos(matcher, path, dis_list, heading_segs, pred_sl_segs, real_sl_segs):
    labels = []
    pred_sl_before = []
    real_sl = []
    for i in range(1, len(path)):
        seg_heading = matcher.Dir[path[i - 1], path[i]]
        # print(matcher.Dis[path[i - 1], path[i]], dis_list[i - 1][1], dis_list[i - 1][0], np.sum(real_sl_segs[i - 1]))
        straight_ratio = dis_list[i - 1][0] / np.sum(pred_sl_segs[i - 1])
        len_ratio = matcher.Dis[path[i - 1], path[i]] / dis_list[i - 1][0]
        print(straight_ratio, len_ratio)
        labels.append([pred_sl_segs[i - 1][j] * len_ratio / np.cos((heading_segs[i - 1][j] - seg_heading) / 180 * np.pi) for j in range(len(pred_sl_segs[i - 1]))])
        pred_sl_before.append([pred_sl for pred_sl in pred_sl_segs[i - 1]])
        real_sl.append([real_sl for real_sl in real_sl_segs[i - 1]])
    return labels, pred_sl_before, real_sl

def divide_segs_by_projection_ratio(matcher, path, dis_list, heading_segs, pred_sl_segs, real_sl_segs):
    labels = []
    pred_sl_before = []
    real_sl = []
    for i in range(1, len(path)):
        seg_heading = matcher.Dir[path[i - 1], path[i]]
        projection_len_sum = np.sum([pred_sl_segs[i - 1][j] * np.cos((heading_segs[i - 1][j] - seg_heading) / 180 * np.pi) for j in range(len(pred_sl_segs[i - 1]))])
        # print(matcher.Dis[path[i - 1], path[i]], dis_list[i - 1][1], np.sum(real_sl_segs[i - 1]), projection_len_sum)
        projection_ratio = matcher.Dis[path[i - 1], path[i]] / projection_len_sum
        print(projection_ratio)
        labels.append([pred_sl_segs[i - 1][j] * projection_ratio / np.cos((heading_segs[i - 1][j] - seg_heading) / 180 * np.pi) for j in range(len(pred_sl_segs[i - 1]))])
        pred_sl_before.append([pred_sl for pred_sl in pred_sl_segs[i - 1]])
        real_sl.append([real_sl for real_sl in real_sl_segs[i - 1]])
    return labels, pred_sl_before, real_sl

def process_file(input_file):
    # input_file='../data/lqrIMU/wqm90627_2.txt'
    data = pd.read_csv(input_file, sep = ' ', names = ['tag', 'acc_x', 'acc_y', 'acc_z', 'gyr_x', 'gyr_y', 'gyr_z', 'mag_x', 'mag_y', 'mag_z', 'timestamp', 'steplength', 'stepcount', 'cumsteplength', 'x', 'y', 'z', 'heading', 'holdingstyle'])
    # data = pd.read_csv(input_file, sep = ' ', names = ['tag', 'acc_x', 'acc_y', 'acc_z', 'gyr_x', 'gyr_y', 'gyr_z', 'mag_x', 'mag_y', 'mag_z', 'timestamp', 'steplength', 'stepcount', 'cumsteplength', 'x', 'y', 'z', 'heading'])
    # data['y'] *= -1
    data.replace('test', 1, inplace = True)
    data['mag_norm'] = (data[['mag_x', 'mag_y', 'mag_z']] ** 2).sum(axis = 1) ** 0.5
    data = data[data['stepcount'] != 0]
    for col in ['steplength', 'x', 'y', 'z']:
        data[col] = [data[col].values[0]] + list(data[col].values)[:-1]
    data.reset_index(drop = True, inplace = True)
    while True:
        new_stepcount = 1
        data['new_stepcount'] = 0
        flag = True
        last_x, last_y = 0, 0
        for step in sorted(data['stepcount'].unique()):
            data.loc[data['stepcount'] == step, 'new_stepcount'] = new_stepcount
            curr_x, curr_y = data[data['stepcount'] == step][['x', 'y']].values[0]
            if data[data['stepcount'] == step]['steplength'].values[0] > 2:
                flag = False
                N = len(data[data['stepcount'] == step])
                data.loc[data['stepcount'] == step, 'steplength'] = data[data['stepcount'] == step]['steplength'].values[0] / 2
                data.loc[data['stepcount'] == step, 'x'] = [(last_x + curr_x) / 2] * (N // 2) + [curr_x] * (N - N // 2)
                data.loc[data['stepcount'] == step, 'y'] = [(last_y + curr_y) / 2] * (N // 2) + [curr_y] * (N - N // 2)
                data.loc[data['stepcount'] == step, 'new_stepcount'] = [new_stepcount] * (N // 2) + [new_stepcount + 1] * (N - N // 2)
                new_stepcount += 1
            new_stepcount += 1
            last_x, last_y = curr_x, curr_y
        print(new_stepcount)
        data['stepcount'] = data['new_stepcount'] 
        if flag:
            del data['new_stepcount']
            break

    data['gyr_diff'] = 0
    for step_num in data['stepcount'].unique():
        data.loc[data['stepcount'] == step_num, 'gyr_diff'] = get_gyr_diff(data[data['stepcount'] == step_num])

    data_backup = data.copy()
    sample_list = []
    for round_num in data_backup['tag'].unique():
        min_stepcount, max_stepcount = data_backup[data_backup['tag'] == round_num]['stepcount'].min(), data_backup[data_backup['tag'] == round_num]['stepcount'].max()
        data = data_backup.loc[(data_backup['stepcount'] > min_stepcount - 5) & (data_backup['stepcount'] < max_stepcount + 5)].copy()
        data.reset_index(drop = True, inplace = True)
        data['stepcount'] = data['stepcount'] - data['stepcount'].min() + 1

        # 先算出每一步的预测步长
        acc, gyr, mag, feat, steps = preprocess(data)
        model = LSTM_Model().model
        pred = model.predict([acc, gyr, feat]).reshape(-1, )
        data['pred_sl'] = data['stepcount'].map({i + 1: pred[i] for i in range(len(pred))}) / 1000

        # 计算将路径对齐到初始方向所需要转过的角度
        cal_theta = -calculate_included_angle([-7, -185], [data.drop_duplicates('stepcount')['x'].values[3], data.drop_duplicates('stepcount')['y'].values[3]])
        print(cal_theta)
        # cal_theta = -calculate_included_angle([-26, 668], [data.drop_duplicates('stepcount')['x'].values[4], data.drop_duplicates('stepcount')['y'].values[4]])
        data['cal_x'], data['cal_y'] = 0, 0
        for i in range(len(data)):
            cal_x, cal_y = rotate_vector([data['x'][i], data['y'][i]], cal_theta)
            data.loc[i, 'cal_x'] = cal_x
            data.loc[i, 'cal_y'] = cal_y

        turn_flag = data['heading'].values[0]
        last_gyr_diff = 0
        last_real_pos = [0, 0]
        last_pred_pos = [0, 0]
        last_step_vec = [0, -1]
        # last_heading = calculate_included_angle([-7, -185], [0, -1])
        last_heading = 0
        headings = []
        heading_win = []
        heading_segs = []
        line_start_point = [0, 0]
        line_start_point_real = [0, 0]
        matcher = MapMatcher()
        # samples = []
        pred_sl_wins = []
        pred_sl_segs = []
        real_sl_wins = []
        real_sl_segs = []
        dis_list = []
        dir_list = []
        start_match = False
        drop_count = 0
        mag_data = []
        mag_data_win = []
        for i, x, y, sl_pred, sl_real, gyr_diff, curr_turn_flag in data.drop_duplicates('stepcount')[['stepcount', 'cal_x', 'cal_y', 'pred_sl', 'steplength', 'gyr_diff', 'heading']].values:

            # 旋转到正确方向
            # x, y = rotate_vector([ox, oy], cal_theta)
            # 当前步的位移矢量
            curr_step_vec = [x - last_real_pos[0], y - last_real_pos[1]]
            # print(norm(curr_step_vec))
            curr_step_vec = scale(curr_step_vec, sl_pred / norm(curr_step_vec))
            heading_change = calculate_included_angle(curr_step_vec, last_step_vec) if i != 1 else 0
            # print(last_real_pos[0], last_real_pos[1], x, y, last_step_vec, curr_step_vec, heading_change)
            if np.isnan(heading_change): break

            if abs(heading_change) > 52:
            # if curr_turn_flag != turn_flag:
            #     turn_flag = curr_turn_flag
            # if abs(last_gyr_diff + gyr_diff) > 60:
                last_gyr_diff = 0
                if start_match:
                    from time import time
                    t0 = time()
                    pdr_dis = calculate_distance(line_start_point, last_pred_pos)
                    real_dis = calculate_distance(line_start_point_real, last_real_pos)
                    dis_list.append([pdr_dis, real_dis])
                    pdr_dir = angle_mean(heading_win)
                    dir_list.append(pdr_dir)
                    mag_data_win = np.hstack(mag_data_win)
                    # mag_data_win -= np.mean(mag_data_win)
                    path, proba, all_proba, p_dtws = matcher.viterbi_decode([[pdr_dis, pdr_dir, mag_data_win]])
                    mag_data.append(mag_data_win.copy())
                    mag_data_win = []
                    pred_sl_segs.append(pred_sl_wins.copy())
                    pred_sl_wins = []
                    real_sl_segs.append(real_sl_wins.copy())
                    real_sl_wins = []
                    heading_segs.append(heading_win.copy())
                    heading_win = []
                    line_start_point = last_pred_pos.copy()
                    line_start_point_real = last_real_pos.copy()
                    # print(path, proba, all_proba, p_dtws)
                    print(path, proba)
                    # print(time() - t0)
                    # break
                else: 
                    start_match = True
                    drop_count = len(heading_win)
                    mag_data_win = []
                    pred_sl_wins = []
                    real_sl_wins = []
                    heading_win = []
                    line_start_point = last_pred_pos.copy()
                    line_start_point_real = last_real_pos.copy()
            else:
                # print(heading_change)
                last_gyr_diff = gyr_diff
            mag_data_win.append(data[data['stepcount'] == i]['mag_norm'].values)
            pred_sl_wins.append(sl_pred)
            real_sl_wins.append(sl_real)
            curr_heading = last_heading + heading_change
            if curr_heading < -180: curr_heading += 360
            if curr_heading > 180: curr_heading -= 360
            headings.append(curr_heading)
            heading_win.append(curr_heading)
            last_step_vec = curr_step_vec
            last_real_pos = [x, y]
            last_pred_pos = [last_pred_pos[0] + curr_step_vec[0], last_pred_pos[1] + curr_step_vec[1]]
            last_heading = curr_heading

        # print(len(path[0]))
        path = path[0]
        # if round_num == 4 and list(path) != [1, 8, 17, 12, 19, 18, 11, 10, 1]: 
        #     continue
        # elif round_num != 4 and list(path) != [1, 8, 17, 16, 21, 20, 15, 12, 19, 18, 11, 10, 1]: 
        #     continue

        labels, pred_sl_before, real_sl = divide_segs_by_len_ratio(matcher, path, dis_list, pred_sl_segs, real_sl_segs)
        labels, pred_sl_before, real_sl = divide_segs_by_len_ratio_cos(matcher, path, dis_list, heading_segs, pred_sl_segs, real_sl_segs)
        labels, pred_sl_before, real_sl = divide_segs_by_projection_ratio(matcher, path, dis_list, heading_segs, pred_sl_segs, real_sl_segs)

        labels = np.hstack(labels) * 1000
        pred_sl_before = np.hstack(pred_sl_before) * 1000
        real_sl = np.hstack(real_sl) * 1000
        print(pd.Series(np.abs(labels - real_sl)).describe())
        print(pd.Series(np.abs(pred_sl_before - real_sl)).describe())
        plt.hist(abs(labels-real_sl)[abs(pred_sl_before-real_sl)<100], bins=500, density=True, histtype='step', cumulative=True, label='labels')
        plt.hist(abs(pred_sl_before-real_sl)[abs(pred_sl_before-real_sl)<100], bins=500, density=True, histtype='step', cumulative=True, label='pred_sl_before')
        plt.show()

        data = data.drop_duplicates('stepcount')[drop_count:-len(heading_win)]
        acc = acc[drop_count:-len(heading_win)]
        gyr = gyr[drop_count:-len(heading_win)]
        feat = feat[drop_count:-len(heading_win)]
        sample_list.append([acc, gyr, feat, labels, pred_sl_before, real_sl])
    return sample_list

if __name__ == '__main__':
    # test_map_matcher()
    # test_sle_model()
    # input_file = '../data/PDR_Raw_2019-01-08-07-54-37.txt'
    sample_list = []
    dire = '../data/wq_p9/'
    # model = LSTM_Model().model
    for file in os.listdir(dire):
        sample_list += process_file(dire + file)
        
    for sample in sample_list:
        model.fit([sample[0], sample[1], sample[2]], np.hstack(sample[3]) * 1000, epochs = 100)


    sample = sample_list[0]
    labels = np.hstack(sample[3]) * 1000
    pred_before = np.hstack(sample[4]) * 1000
    real = np.hstack(sample[5]) * 1000
