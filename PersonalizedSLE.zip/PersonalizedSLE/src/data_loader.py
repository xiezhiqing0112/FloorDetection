import pandas as pd
import numpy as np
import os
from tensorflow.keras.preprocessing.sequence import pad_sequences

MIN_STEP_LENGTH = 1
MAX_STEP_LENGTH = 1.8
MIN_TIME_STEP = 80
MAX_TIME_STEP = 300

def read_data(dire):
    data = pd.DataFrame(columns = ['tag', 'acc_x', 'acc_y', 'acc_z', 'gyr_x', 'gyr_y', 'gyr_z', 
        'mag_x', 'mag_y', 'mag_z', 'timestamp', 'steplength', 'stepcount', 'cumsteplength'])
    max_step_count = 0
    for file in os.listdir(dire):
        temp = pd.read_csv(dire + file, sep = ' ', 
            names = ['tag', 'acc_x', 'acc_y', 'acc_z', 'gyr_x', 'gyr_y', 'gyr_z', 'mag_x', 'mag_y', 'mag_z', 
            'timestamp', 'steplength', 'stepcount', 'cumsteplength'])
        temp = temp[temp['stepcount'] != 0]
        temp['stepcount'] += max_step_count
        max_step_count = temp['stepcount'].max()
        data = data.append(temp)
    data['steplength'] = [data['steplength'].values[0]] + list(data['steplength'].values)[:-1]
    data = data.loc[(data['steplength'] > MIN_STEP_LENGTH) & (data['steplength'] < MAX_STEP_LENGTH)]
    data.reset_index(drop = True, inplace = True)
    del data['tag']
    del data['cumsteplength']

    return data

def array_stats(data):
    return [data.mean(), data.max(), data.min(), data.std()]

def extract_statistic_features(data):
    feats = []
    # for sensor in ['acc', 'gyr', 'mag']:
    for sensor in ['acc', 'gyr']:
        magnitude = (data[[sensor + '_x', sensor + '_y', sensor + '_z']] ** 2).sum(axis = 1) ** 0.5
        feats += array_stats(magnitude)
        if sensor == 'acc':
            feats.append(np.power(np.max(magnitude) - np.min(magnitude), 1 / 4))
            feats.append(np.power(np.mean(np.abs(magnitude)), 1 / 3))
            feats.append((np.mean(np.abs(magnitude)) - np.min(magnitude)) / (np.max(magnitude) - np.min(magnitude)))
        for axis in ['x', 'y', 'z']:
            feats += array_stats(data[sensor + '_' + axis])
    return feats

def preprocess(data):
    global STAT_FEAT_DIM
    sample_counts = data.groupby('stepcount', as_index = False)['steplength'].count()
    # step_counts = sample_counts.loc[(sample_counts['steplength'] < MAX_TIME_STEP) & (sample_counts['steplength'] > 80), 'stepcount'].values
    step_counts = sample_counts['stepcount'].values

    acc_data, gyr_data, mag_data, steps = [], [], [], []
    feat_data = []
    # for x in tqdm(list(data.groupby('stepcount'))):
    for x in list(data.groupby('stepcount')):
        if x[0] in step_counts:
            feat_data.append(extract_statistic_features(x[1]))
            acc_data.append(x[1][['acc_x' ,'acc_y' ,'acc_z']])
            gyr_data.append(x[1][['gyr_x', 'gyr_y' ,'gyr_z']])
            mag_data.append(x[1][['mag_x', 'mag_y' ,'mag_z']])
            steps.append(x[1]['steplength'].values[0])
    acc_data = pad_sequences(acc_data, maxlen = MAX_TIME_STEP, dtype = 'float32', value = -99999)
    gyr_data = pad_sequences(gyr_data, maxlen = MAX_TIME_STEP, dtype = 'float32', value = -99999)
    mag_data = pad_sequences(mag_data, maxlen = MAX_TIME_STEP, dtype = 'float32', value = -99999)
    feat_data = np.array(feat_data) / 30
    STAT_FEAT_DIM = feat_data.shape[1]
    steps = np.array(steps)
    steps *= 1000

    return acc_data, gyr_data, mag_data, feat_data, steps

def preprocess_new_steps(data):
    global STAT_FEAT_DIM
    acc_data, gyr_data, mag_data = [], [], []
    feat_data = []
    # for x in tqdm(list(data.groupby('stepcount'))):
    feat_data.append(extract_statistic_features(data))
    acc_data.append(data[['acc_x' ,'acc_y' ,'acc_z']])
    gyr_data.append(data[['gyr_x', 'gyr_y' ,'gyr_z']])
    mag_data.append(data[['mag_x', 'mag_y' ,'mag_z']])
    acc_data = pad_sequences(acc_data, maxlen = MAX_TIME_STEP, dtype = 'float32', value = -99999)
    gyr_data = pad_sequences(gyr_data, maxlen = MAX_TIME_STEP, dtype = 'float32', value = -99999)
    mag_data = pad_sequences(mag_data, maxlen = MAX_TIME_STEP, dtype = 'float32', value = -99999)
    feat_data = np.array(feat_data) / 30
    STAT_FEAT_DIM = feat_data.shape[1]

    return acc_data, gyr_data, mag_data, feat_data