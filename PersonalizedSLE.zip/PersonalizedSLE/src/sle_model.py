import signal

import pandas as pd
import numpy as np
np.random.seed(180205)
import tensorflow as tf
# tf.set_random_seed(180205)
import os
import time
from tensorflow.keras.layers import Dense, Input, LSTM, Embedding, Masking, Dropout
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.losses import mse
from tensorflow.keras.optimizers import RMSprop, SGD
from tensorflow.keras.initializers import glorot_uniform, Orthogonal
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, TensorBoard, ReduceLROnPlateau
import tensorflow.keras as keras
from tensorflow.keras import backend as K

MODEL_FILE = '../model/model-105-2010.4843.h5'

MIN_STEP_LENGTH = 1
MAX_STEP_LENGTH = 1.8
MIN_TIME_STEP = 80
MAX_TIME_STEP = 300
STAT_FEAT_DIM = 35

BATCH_SIZE = 128
EPOCHS = 500
EPOCHS_SDAE = 50
BATCH_EPOCH = 50
EARLY_STOPPING_PATIENCE = 50
# EARLY_STOPPING_PATIENCE_SDAE = 10

TIME_TAG = time.asctime().replace(':', '_')

RANDOM_INIT_COUNT = 42

LOG_DIRE = 'log'
MODEL_DIRE = 'model'

def save_results(history, model, valid_dataset):
    min_epoch = np.argmin(history.history['val_loss'])
    min_loss = history.history['val_loss'][min_epoch]

    direname = '%s%s/' % (LOG_DIRE, TIME_TAG)
    if not os.path.exists(direname):
        os.mkdir(direname)

    # history
    pd.DataFrame(history.history).to_csv(direname + 'history_%.4f.csv' % min_loss, index=False)
    # model
    # model.load_weights(MODEL_DIRE + 'model-%03d-%.4f.h5' % (min_epoch, min_loss))
    # model.save(direname + 'model-%03d-%.4f.h5' % (min_epoch, min_loss))
    # validation
    valid_pred = model.predict(valid_dataset['data']).reshape(-1, )
    pd.DataFrame({
        'pred': valid_pred,
        'label': valid_dataset['label'],
    }).to_csv(direname + 'pred_%.4f.csv' % min_loss, index=False)

class LSTM_Model(object):
    """docstring for LSTM"""
    def __init__(self, model_filename = MODEL_FILE):
        super(LSTM_Model, self).__init__()
        self.model = self.build_model()
        # self.model.load_weights(model_filename)
        # return
        
    def build_model(self):
        acc_input = Input(shape = (MAX_TIME_STEP, 3), name = 'Acc_Input')
        gyr_input = Input(shape = (MAX_TIME_STEP, 3), name = 'Gyr_Input')
        feat_input = Input(shape = (STAT_FEAT_DIM, ), name = 'Feat_Input')
        acc_mask = Masking(mask_value = -99999, name = 'Acc_Mask')(acc_input)
        gyr_mask = Masking(mask_value = -99999, name = 'Gyr_Mask')(gyr_input)
        acc_lstm = LSTM(
            64, 
            name = 'Acc_LSTM',
            kernel_initializer = glorot_uniform(seed = 42),
            recurrent_initializer = Orthogonal(seed = 43),
            bias_initializer = 'zeros',
            )(acc_mask)
        gyr_lstm = LSTM(
            64, 
            name = 'Gyr_LSTM',
            kernel_initializer = glorot_uniform(seed = 44),
            recurrent_initializer = Orthogonal(seed = 45),
            bias_initializer = 'zeros',
            )(gyr_mask)
        merged = keras.layers.concatenate([acc_lstm, gyr_lstm, feat_input], axis = 1, name = 'Merge')

        dropout = Dropout(
            rate = 0.05, 
            name = 'Encoder_Dropout', 
            seed = 42,
            )(merged)
        encoder = Dense(
            32, 
            kernel_initializer = glorot_uniform(seed = 46), 
            bias_initializer = 'zeros',
            activation = 'sigmoid', 
            name = 'Encoder',
            )(dropout)
        dense_1 = Dense(
            16, 
            activation = 'relu', 
            name = 'Dense_1',
            kernel_initializer = glorot_uniform(seed = 47),
            bias_initializer = 'zeros',
            )(encoder)
        dense_2 = Dense(
            8, 
            activation = 'relu', 
            name = 'Dense_2',
            kernel_initializer = glorot_uniform(seed = 48),
            bias_initializer = 'zeros',
            )(dense_1)
        prediction = Dense(
            1, 
            name = 'Prediction',
            kernel_initializer = glorot_uniform(seed = 49),
            bias_initializer = 'zeros',
            )(dense_2)
        model_final = Model(inputs = [acc_input, gyr_input, feat_input], outputs = [prediction])
        rmsprop = RMSprop(lr = 0.001, rho = 0.9, epsilon = 1e-6)
        model_final.compile(optimizer = rmsprop, loss = mse)

        return model_final

    def train(model, train_dataset, test_dataset, save = True):
        np.random.seed(42)
        if save:
            reduce_LR_on_plateau = ReduceLROnPlateau(
                monitor = 'val_loss', 
                factor = 0.9, 
                patience = 20, 
                min_lr = 0.0001,
                )
            check_point = ModelCheckpoint(
                LOG_DIRE + TIME_TAG + MODEL_DIRE + 'model-{epoch:03d}-{val_loss:.4f}.h5', 
                monitor = 'val_loss', 
                save_best_only = True,
                )
            early_stopping = EarlyStopping(
                monitor = 'val_loss', 
                patience = EARLY_STOPPING_PATIENCE,
                )
            tensor_board = TensorBoard(
                LOG_DIRE + TIME_TAG + '/tensorboard_model/', 
                histogram_freq=1, 
                write_graph=True, 
                write_images=True,
                )
            history = model.fit(
                    train_dataset['data'],
                    train_dataset['label'], 
                    validation_data = (test_dataset['data'], test_dataset['label']),
                    batch_size = BATCH_SIZE, 
                    epochs = EPOCHS, 
                    verbose = 1,
                    # callbacks = [check_point, early_stopping, tensor_board]
                    callbacks = [reduce_LR_on_plateau, check_point, early_stopping],
                    shuffle = False,
                    )    
            save_results(history, model, test_dataset)
        else:
            reduce_LR_on_plateau = ReduceLROnPlateau(
                monitor = 'val_loss', 
                factor = 0.9, 
                patience = 20, 
                min_lr = 0.0001,
                )
            # check_point = ModelCheckpoint(LOG_DIRE + TIME_TAG + MODEL_DIRE + 'model-{epoch:03d}-{val_loss:.4f}.h5', monitor = 'val_loss', save_best_only = True)
            early_stopping = EarlyStopping(
                monitor = 'val_loss', 
                patience = EARLY_STOPPING_PATIENCE,
                )
            # tensor_board = TensorBoard(LOG_DIRE + TIME_TAG + '/tensorboard/', histogram_freq=1, write_graph=True, write_images=True)
            history = model.fit(
                    train_dataset['data'],
                    train_dataset['label'], 
                    validation_data = (test_dataset['data'], test_dataset['label']),
                    batch_size = BATCH_SIZE, 
                    epochs = EPOCHS, 
                    verbose = 1,
                    # callbacks = [check_point, early_stopping, tensor_board]
                    callbacks = [reduce_LR_on_plateau, early_stopping],
                    shuffle = False,
                    )

    def train_on_batch(self, train_dataset):
        np.random.seed(42)
        reduce_LR_on_plateau = ReduceLROnPlateau(
            monitor = 'val_loss', 
            factor = 0.9, 
            patience = 20, 
            min_lr = 0.0001,
            )
        history = self.model.fit(
                train_dataset['data'],
                train_dataset['label'], 
                validation_data = (train_dataset['data'], train_dataset['label']),
                batch_size = BATCH_SIZE, 
                epochs = BATCH_EPOCH, 
                verbose = 1,
                callbacks = [reduce_LR_on_plateau],
                shuffle = False,
                )

def find_nearest(array, tag):
    return np.where(np.abs(array - tag) == np.min(np.abs(array - tag)))[0][0]

def readFileData(file):
    imu_data = pd.read_csv('new_data/raw_data/' + file + '.imu', delimiter='\t', header=None)
    imu_data = imu_data[3001:]
    acc = imu_data.iloc[:, 4:7] * 100
    gyro = imu_data.iloc[:, 1:4] * 100
    # lstm_detector = lstm.LSTM()
    # zv_lstm = lstm_detector(imu_res.to_numpy())
    # imu_res.iloc[:, 2] = imu_res.iloc[:, 2] - 1
    label_data = pd.read_csv('new_data/label/' + file + '_label.txt', delimiter=' ', header=None)
    zupt_data = pd.read_csv('new_data/zupt_tag/' + file + '_zupt.txt', delimiter='\t', header=None)
    pos_data = pd.read_csv('new_data/extra_feat/' + file + '_x_y.txt', delimiter=' ', header=None)
    pos_data = pos_data.iloc[:, 1:] * 1000
    imu_res = pd.DataFrame(np.concatenate([acc, gyro], axis=1))
    temp_label = signal.resample(label_data, len(imu_data))
    temp_zupt = np.zeros([len(temp_label), 2])
    label = temp_label
    label[:, 0] = imu_data.iloc[:, 0]
    label[:, 1:] = label[:, 1:] * 1000

    stationaryEnd = np.where(np.diff(zupt_data.iloc[:, 1]) == 1)[0]
    stationaryStart = np.where(np.diff(zupt_data.iloc[:, 1]) == -1)[0]
    stationaryEnd[0] = 0
    stationaryStart_time = zupt_data.iloc[stationaryStart, 0]
    stationaryEnd_time = zupt_data.iloc[stationaryEnd, 0]
    stationaryEnd_time.reset_index(inplace=True, drop=True)
    stationaryStart_time.reset_index(inplace=True, drop=True)
    for i in range(len(stationaryStart)):
        strat_tag = find_nearest(label[:, 0], stationaryStart_time.iloc[i])
        end_tag = find_nearest(label[:, 0], stationaryEnd_time.iloc[i])
        temp_zupt[end_tag:strat_tag, 1] = 1

    temp_zupt[:, 0] = temp_label[:, 0]

    # imu_res = np.concatenate([acc,gyro],axis=1)
    # label = np.loadtxt(file + 'press_label.txt')
    return [imu_res, pos_data, label, temp_zupt]

def array_stats(data):
    return [data.mean(), data.max(), data.min(), data.std()]

def extract_statistic_features(data):
    feats = []
    # for sensor in ['acc', 'gyr', 'mag']:
    magnitude_acc = (data[:, 0:3] ** 2).sum(axis=1) ** 0.5
    magnitude_gyro = (data[:, 3:6] ** 2).sum(axis=1) ** 0.5
    feats += array_stats(magnitude_acc)
    feats += array_stats(magnitude_gyro)
    feats.append(np.power(np.max(magnitude_acc) - np.min(magnitude_acc), 1 / 4))
    feats.append(np.power(np.mean(np.abs(magnitude_acc)), 1 / 3))
    feats.append(
        (np.mean(np.abs(magnitude_acc)) - np.min(magnitude_acc)) / (np.max(magnitude_acc) - np.min(magnitude_acc)))
    feats += array_stats(data[:, 0])
    feats += array_stats(data[:, 1])
    feats += array_stats(data[:, 2])
    feats += array_stats(data[:, 3])
    feats += array_stats(data[:, 4])
    feats += array_stats(data[:, 5])

    return feats

def step_spilt(imu, pos_feat, label, zv_lstm):
    # diff_label = abs(np.diff(label, axis=0))
    diff_zupt = np.diff(zv_lstm, axis=0)
    zupt_start = np.where(diff_zupt == -1)[0]
    zupt_end = np.where(diff_zupt == 1)[0]
    zupt_start = zupt_start[0:-1]
    diff_label = label[zupt_end, :-1] - label[zupt_start, :-1]
    diff_pos = pos_feat.iloc[zupt_end, :-1].to_numpy() - pos_feat.iloc[zupt_start, :-1].to_numpy()
    stationary_imu = np.mean(imu[:zupt_start[0]], axis=0)
    # step_index = np.where(
    #     (np.linalg.norm(diff_label[:, 0:2], axis=1) > 20) & (np.linalg.norm(diff_label[:, 0:2], axis=1) < 250))[0]
    # step_index = np.where(diff_label[:, 3] > 0.1)[0]
    imu_data_ = np.ones([zupt_start.size, 100, 6])
    pos_feat_ = np.ones([zupt_start.size, 100, 3])
    extra_feat_ = np.ones([zupt_start.size, 35])
    for i in range(zupt_start.size - 1):
        if 30 < (zupt_end[i] - zupt_start[i]) < 100:
            imu_data_[i, 0:(zupt_end[i] - zupt_start[i])] = imu[zupt_start[i]:zupt_end[i]].to_numpy()
            imu_data_[i, (zupt_end[i] - zupt_start[i]):] = imu_data_[i, (zupt_end[i] - zupt_start[
                i]):] * stationary_imu.to_numpy()
            pos_feat_[i, 0:(zupt_end[i] - zupt_start[i])] = pos_feat[zupt_start[i]:zupt_end[i]].to_numpy()
            pos_feat_[i, (zupt_end[i] - zupt_start[i]):] = pos_feat_[i, (zupt_end[i] - zupt_start[
                i]):] * pos_feat.iloc[zupt_end[i] - 1].to_numpy()
            pos_feat_[i] = pos_feat_[i] - pos_feat_[i, 0]
        elif (zupt_end[i] - zupt_start[i]) >= 100:
            temp = imu.iloc[zupt_start[i]:zupt_end[i], :].to_numpy()
            temp_res = signal.resample(temp, 100)
            temp_pos = pos_feat.iloc[zupt_start[i]:zupt_end[i], :].to_numpy()
            temp_pos_res = signal.resample(temp_pos, 104)
            imu_data_[i] = temp_res
            pos_feat_[i] = temp_pos_res[2:102]
            pos_feat_[i] = pos_feat_[i] - pos_feat_[i, 0]
        else:
            imu_data_[i] = imu_data_[i - 1]
            pos_feat_[i] = pos_feat_[i - 1]
            diff_label[i] = diff_label[i - 1]
        extra_feat_[i] = extract_statistic_features(imu_data_[i])
    imu_data_ = np.concatenate([imu_data_, pos_feat_,
                                np.linalg.norm(pos_feat_, axis=2).reshape(pos_feat_.shape[0], pos_feat_.shape[1],
                                                                          1)], axis=2)
    imu_data_ = imu_data_.reshape(-1, 10)
    return imu_data_, extra_feat_, np.linalg.norm(diff_label, axis=1)


def readData(directory):
    imus = []
    extra_feats = []
    labels = []
    with open(directory) as f:
        data_list = [s.strip().split(',')[0] for s in f.readlines() if len(s) > 0 and s[0] != '#']
    count = 1
    for file in data_list:
        # fileName = os.path.basename(file)
        # (name, ext) = os.path.splitext(fileName)
        # parts = name.split("_")
        # if (len(parts) == 2):
        imu, pos_feat, label, zv_lstm = readFileData(file)
        imu_pro, extra_feat, label_pro = step_spilt(imu, pos_feat, label, zv_lstm)
        # label = fileData[:, 4]
        if imu_pro is not None:
            imus.append(imu_pro)
            extra_feats.append(extra_feat)
            labels.append(label_pro)
        else:
            # print("{} is useless. count {} in total {}".format(file, count, len(allFiles)))
            count = count + 1
    return np.asarray(imus), np.asarray(extra_feats), np.asarray(labels)

# if __name__ == '__main__':
#     train_data = read_data(TRAIN_DATA_DIRE)
#     test_data = read_data(TEST_DATA_DIRE)
#     train_acc, train_gyr, train_mag, train_feat, train_steps = preprocess(train_data)
#     test_acc, test_gyr, test_mag, test_feat, test_steps = preprocess(test_data)
#
#     train_dataset = {'data': [train_acc, train_gyr, train_feat], 'label': train_steps}
#     test_dataset = {'data': [test_acc, test_gyr, test_feat], 'label': test_steps}
#     model_final = build_model(sdae)
#     train_model(model_final, train_dataset, test_dataset, save = True)