import numpy as np
import pandas as pd
import _ucrdtw
import dtw
import math
import os
import re
import sys
import cv2
import matplotlib.pyplot as plt

class MapMatcher(object):
    def __init__(self):
        self.KP = [
            [148, 409], [188, 407], [241, 407], [289, 404],
            [339, 402], [492, 397], [546, 396], [589, 395],
            [645, 392], [155, 620], [196, 618], [249, 617],
            [298, 615], [349, 612], [497, 608], [553, 606],
            [600, 605], [655, 602], [243, 512], [293, 509],
            [548, 499], [598, 497],
        ]
        self.SC = [
            [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
            [1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0],
            [1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
            [1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            [1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0],
            [1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            [0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0],
            [0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
            [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0]
        ]
        self.mag_finger_print = self.load_mag_finger_print()
        self.scale = 12
        self.N = len(self.KP)
        for i in range(self.N):
            self.KP[i][0] /= self.scale
            self.KP[i][1] /= self.scale
        self.Dis = np.ones((self.N, self.N)) * sys.maxsize
        self.Dir = np.ones((self.N, self.N)) * np.nan
        for i in range(self.N):
            for j in range(self.N):
                if i == j:
                    self.Dir[i][j] = 0
                if self.SC[i][j] == 0:
                    continue
                self.Dis[i][j] = np.sqrt((self.KP[i][0] - self.KP[j][0]) ** 2 + (self.KP[i][1] - self.KP[j][1]) ** 2)
                vec = [self.KP[j][0] - self.KP[i][0], self.KP[j][1] - self.KP[i][1]]
                theta = math.acos(-vec[1] / np.linalg.norm(vec)) / np.pi * 180
                if vec[0] < 0: theta = 360 - theta
                self.Dir[i][j] = theta

        self.Dis_std = np.ones((self.N, self.N)) * 1
        self.Dir_std = np.ones((self.N, self.N)) * 15

        # 模型参数
        self.A = 1 / self.Dis
        self.A = (self.A / np.sum(self.A, axis = 1)) # 转移矩阵
        self.Pi = (np.ones(self.N) / self.N).transpose()
        self.Pi[1] = 100
        self.A = np.log(self.A)
        self.Pi = np.log(self.Pi)
        self.p_nodes = self.Pi
        self.path_nodes = [[i] for i in range(self.N)]
        return

    def load_mag_finger_print(self):
        finger_print = [[np.array([0]) for i in range(len(self.KP))] for j in range(len(self.KP))]
        sample_routes = [list(range(0, 9)), list(range(9, 18)), 
            [2, 18, 11], [3, 19, 12], [6, 20, 15], [7, 21, 16],
            [0, 9], [1, 10], [4, 13], [5, 14], [8, 17], [18, 19], [20, 21]]
        for filename in os.listdir('../data/mag_data/huawei_mate_9'):
            start, end = list(map(int, re.findall('Mag_Data_(.+?).txt', filename)[0].split('_')))
            data = pd.read_csv('../data/mag_data/huawei_mate_9/' + filename)
            data['norm'] = (data[['x', 'y', 'z']] ** 2).sum(axis = 1) ** 0.5
            for route in sample_routes:
                if set([start, end]) == set([route[0], route[-1]]):
                    if start == route[-1] and end == route[0]: 
                        data['norm'] = data['norm'].values[::-1]
                        data['seg'] = data['seg'].values[::-1]
                        data['seg'] = data['seg'].max() - data['seg']
                    for i in range(len(route) - 1):
                        for j in range(i + 1, len(route)):
                            # finger_print[route[i]][route[j]] = data.loc[(data['seg'] >= i) & (data['seg'] < j)]['norm'].values - np.mean(data.loc[(data['seg'] >= i) & (data['seg'] < j)]['norm'].values)
                            # finger_print[route[j]][route[i]] = data.loc[(data['seg'] >= i) & (data['seg'] < j)]['norm'].values[::-1] - np.mean(data.loc[(data['seg'] >= i) & (data['seg'] < j)]['norm'].values)
                            finger_print[route[i]][route[j]] = data.loc[(data['seg'] >= i) & (data['seg'] < j)]['norm'].values
                            finger_print[route[j]][route[i]] = data.loc[(data['seg'] >= i) & (data['seg'] < j)]['norm'].values[::-1]

        return finger_print

    def emit_p(self, i, j, observation):
        d, theta, mag_seq = observation
        # if len(self.mag_finger_print[i][j]) == 1: dtw_dist = 39.5852547312
        # else: 
        #     dtw_dist = dtw.fastdtw(mag_seq[::5], self.mag_finger_print[i][j][::5], lambda x, y: (x - y) ** 2)[0]
            # loc, dtw_dist = _ucrdtw.ucrdtw(self.mag_finger_print[i][j], mag_seq, 0.05, False)
        # return np.log((2 * np.pi * self.Dis_std[i][j] * self.Dir_std[i][j]) ** -1 * np.exp(-0.5 * (((d - self.Dis[i][j]) / self.Dis_std[i][j]) ** 2 + ((theta - self.Dir[i][j] if abs(theta - self.Dir[i][j]) < 180 else 360 - abs(theta - self.Dir[i][j])) / self.Dir_std[i][j]) ** 2)) + 1e-32) + np.log(1 / dtw_dist), dtw_dist
        return np.log((2 * np.pi * self.Dis_std[i][j] * self.Dir_std[i][j]) ** -1 * np.exp(-0.5 * (((d - self.Dis[i][j]) / self.Dis_std[i][j]) ** 2 + ((theta - self.Dir[i][j] if abs(theta - self.Dir[i][j]) < 180 else 360 - abs(theta - self.Dir[i][j])) / self.Dir_std[i][j]) ** 2)) + 1e-32), 0

    def viterbi_decode(self, observations):
        """维特比解码,所有概率为对数概率。
        输入：
            A: N×N 的转移矩阵
            emit_p: 发射概率函数
            Pi: list, 初始状态概率分布
            observations: list, 观测序列
        返回：
            max_path: list, 最优路径。
        """
        T = len(observations)
        # T 个时刻
        for step in range(1, T + 1):
            new_path_nodes = []
            new_p_nodes = []
            new_p_dtws = []
            for this_node in range(self.N):   # 计算每个节点的新概率
                new_path_nodes.append(self.path_nodes[this_node].copy())
                new_p_nodes.append(self.p_nodes[this_node].copy())
                p_news = []
                p_dtws = []
                for last_node in range(self.N):
                    if np.isnan(self.Dir[last_node, this_node]): 
                        p_news.append(-np.inf)
                        p_dtws.append(sys.maxsize)
                        continue
                    p_trans = self.A[last_node, this_node]  # 转移概率
                    # p_out = B[this_node, O[step]]       # 输出概率
                    p_out, p_dtw = self.emit_p(last_node, this_node, observations[step - 1])
                    # p_new = self.p_nodes[last_node] / 3 + p_trans + p_out
                    p_new = self.p_nodes[last_node] + p_trans + p_out
                    p_news.append(p_new)
                    p_dtws.append(p_dtw)
                new_p_dtws.append(np.min(p_dtws))
                new_p_nodes[this_node] = np.max(p_news)    # 更新节点路径概率
                last_index = np.argmax(p_news)         # 更新节点路径
                temp = self.path_nodes[last_index][:]
                temp.append(this_node)
                new_path_nodes[this_node] = temp
            self.path_nodes = new_path_nodes
            self.p_nodes = new_p_nodes
        # max_index = np.argmax(p_nodes)
        max_index = np.argpartition(self.p_nodes, (len(self.p_nodes) - 3, len(self.p_nodes) - 1))[-1:-4:-1]
        proba = np.exp(self.p_nodes)
        proba /= np.sum(proba)
        return np.array(self.path_nodes)[max_index], proba[max_index], proba, np.array(new_p_dtws)
